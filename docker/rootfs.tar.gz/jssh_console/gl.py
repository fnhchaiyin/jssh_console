thread_num=10
jssh={}
prompt=''